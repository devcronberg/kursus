# Visual Studio Snippets

Jeg syntes der mangler et par C# snippets i VS (2019) så derfor benytter jeg selv disse

- cws (Console.WriteLine med string template)
- method0 (standard metode uden argumenter)
- method0s (standard statisk metode uden argumenter)
- method1 (standard metode med et argument)
- method1s (standard statisk metode med et argument)

[Hent de enkelte filer](https://github.com/devcronberg/kursus/tree/master/vs) til en temp mappe, og importer dem i VS via Tools-menuen, Code Snippet Manager - husk at vælge C# som sprog, valg My Code Snippets, og herefter klik på Import.
